# API overview — demo build

All endpoints are same-origin. JSON writes use `Content-Type: application/json`. The browser obtains a session CSRF token from `GET /api/bootstrap` and sends it as `X-CSRF-Token`. Administrative endpoints additionally require the admin session.

## Public

| Method | Path | Purpose |
|---|---|---|
| GET | `/api/health` | Readiness check, including DB connectivity |
| GET | `/api/bootstrap?guest_id=...` | Demo catalog, active promos/contests/prizes, site copy, visitor balance and CSRF token |
| GET | `/api/products` | Active catalog |
| POST | `/api/events` | Allow-listed anonymous funnel event |
| POST | `/api/checkout/quote` | Server-side cart/promo/delivery quote; client prices ignored |
| POST | `/api/orders` | Demo-only checkout; stores synthetic labels, discards entered name/phone |
| GET | `/api/game/profile?guest_id=...` | Anonymous demo balance |
| POST | `/api/game/daily-ticket` | One free daily demo ticket per guest ID |
| POST | `/api/game/spin` | Server-side weighted prize draw; decrements ticket and prize stock |
| GET | `/api/game/history?guest_id=...` | Own demo spin history |
| POST | `/api/contests/{id}/entries` | One anonymous demo entry per contest and guest ID |
| GET | `/api/contests/{id}/entries/count` | Public entry count |

## Admin HTML and API

- `/admin/login` — password-hash protected login; in-memory lockout after repeated failures.
- `/admin` — administrative control center.
- `/admin/logout` — CSRF-protected logout.
- `/api/admin/dashboard`, `/orders`, `/products`, `/promotions`, `/prizes`, `/spins`, `/contests`, `/content`, `/settings`, `/integrations`, `/analytics`, `/audit` — management and reporting.
- Mutations: `POST/PATCH` for catalog, order status, promos, prizes, contests, content and `PUT /api/admin/settings` for storefront copy.
- `POST /api/admin/contests/{id}/draw` — server-side demo winner selection and persisted winner/audit record.
- `POST /api/admin/content/{id}/publish` — deliberately refuses to claim success: returns `409` until credentials exist and `501` until a real publisher adapter is implemented and tested.

## Important boundaries

- `DEMO_MODE=true` is required for preview. Real checkout is disabled when demo mode is false until production dependencies are implemented.
- Demo tickets are free; there are no paid entries, stakes or cash prizes.
- Guest IDs are anonymous browser identifiers, not production identity verification.
- SQLite in `/tmp` is ephemeral on Render. Do not store live customer or financial records here.
- Presence of API credentials is not a successful integration test.
