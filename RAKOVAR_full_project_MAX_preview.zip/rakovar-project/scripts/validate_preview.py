from __future__ import annotations
import ast
import pathlib
import sqlite3
import subprocess
import sys

ROOT = pathlib.Path(__file__).resolve().parents[1]
sys.path.insert(0, str(ROOT))
from catalog_seed import CATALOG_PRODUCTS

# Syntax checks
for name in ('app.py', 'max_auth.py', 'max_client.py', 'max_bot.py', 'catalog_seed.py', 'start_render_preview.py'):
    ast.parse((ROOT / name).read_text(encoding='utf-8'), filename=name)
for name in ('static/storefront.js', 'static/admin.js'):
    subprocess.run(['node', '--check', str(ROOT / name)], check=True)

# Verify schema DDL and seed inserts without importing Flask.
module = ast.parse((ROOT / 'app.py').read_text(encoding='utf-8'))
function_names={n.name for n in module.body if isinstance(n, ast.FunctionDef)}
assert {'normalize_cart','discount_for','eligible_promotion','event','max_auth','get_loyalty_rate','admin_contest_update','admin_loyalty_award','admin_loyalty_rules_update','referral_profile','referral_attach','admin_referrals','admin_referral_rules_update'}.issubset(function_names)
assert 'price_on_request' in (ROOT / 'app.py').read_text(encoding='utf-8')
init_fn = next(n for n in module.body if isinstance(n, ast.FunctionDef) and n.name == 'init_db')
ddl = None
for node in ast.walk(init_fn):
    if isinstance(node, ast.Call) and isinstance(node.func, ast.Attribute) and node.func.attr == 'executescript' and node.args and isinstance(node.args[0], ast.Constant):
        ddl = node.args[0].value
        break
if not ddl:
    raise SystemExit('Could not locate init_db schema DDL')
conn = sqlite3.connect(':memory:')
conn.executescript(ddl)
columns = {row[1] for row in conn.execute('PRAGMA table_info(products)')}
required = {'image_url','source_url','price_verified','stock_confirmed','weight_label','price_on_request'}
assert conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='integration_health'").fetchone()
assert conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='ticket_ledger'").fetchone()
assert conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='referral_codes'").fetchone()
assert conn.execute("SELECT name FROM sqlite_master WHERE type='table' AND name='referral_attributions'").fetchone()
assert required.issubset(columns), required - columns
conn.execute('''INSERT INTO products(id,title,category,price,unit,stock,description,image,badge,created_at,image_url,source_url,price_verified,stock_confirmed,weight_label,price_on_request)
VALUES(?,?,?,?,?,?,?,?,?,?,?,?,?,?,?,?)''', ('sample','Sample','Test',1,'шт.',1,'','opt_hero.svg','', 'now','','',0,0,'',0))
conn.execute('''INSERT INTO ticket_ledger(guest_id,delta,reason,source_type,source_id,metadata_json,created_at) VALUES(?,?,?,?,?,?,?)''', ('guest-test-id-12345',3,'demo','demo_onboarding','initial','{}','now'))
try:
    conn.execute('''INSERT INTO ticket_ledger(guest_id,delta,reason,source_type,source_id,metadata_json,created_at) VALUES(?,?,?,?,?,?,?)''', ('guest-test-id-12345',3,'duplicate','demo_onboarding','initial','{}','now'))
except sqlite3.IntegrityError:
    pass
else:
    raise AssertionError('ticket ledger idempotency constraint missing')
assert len(CATALOG_PRODUCTS) >= 60
assert len({p['id'] for p in CATALOG_PRODUCTS}) == len(CATALOG_PRODUCTS)
assert all(p['price_verified'] == 0 and p['stock_confirmed'] == 0 for p in CATALOG_PRODUCTS)
assert all(not p['image_url'] for p in CATALOG_PRODUCTS)  # no unlicensed third-party hotlinks in the demo
assert not (ROOT / '.env').exists(), 'A real .env must never be included in a distributable preview.'
print(f'PASS: Python/JS syntax, SQLite schema, ledger/referral constraints, {len(CATALOG_PRODUCTS)} catalog items')
