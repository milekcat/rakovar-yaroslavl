(() => {
  const $ = (s, root = document) => root.querySelector(s);
  const $$ = (s, root = document) => [...root.querySelectorAll(s)];
  const money = n => new Intl.NumberFormat('ru-RU').format(Number(n || 0)) + ' ₽';
  const esc = s => String(s ?? '').replace(/[&<>"']/g, c => ({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
  const guestKey = 'rakovar_demo_guest';
  const cartKey = 'rakovar_demo_cart';
  const state = { products: [], csrf: '', guestId: '', cart: {}, category: 'all', search: '', sort: 'popular', promo: '', delivery: 'delivery', contests: [], referral: null, maxStartParam: '' };

  function getGuestId() {
    let id = localStorage.getItem(guestKey);
    if (!id) {
      id = (crypto.randomUUID ? crypto.randomUUID() : 'guest-' + Math.random().toString(36).slice(2) + Date.now()).replace(/[^a-zA-Z0-9-]/g, '').slice(0, 72);
      localStorage.setItem(guestKey, id);
    }
    return id;
  }
  async function api(url, options = {}) {
    const headers = { ...(options.body ? {'Content-Type':'application/json'} : {}), ...(options.headers || {}) };
    if (options.method && options.method !== 'GET' && state.csrf) headers['X-CSRF-Token'] = state.csrf;
    const res = await fetch(url, { credentials: 'same-origin', ...options, headers });
    const data = await res.json().catch(() => ({}));
    if (!res.ok) throw new Error(data.message || data.error || `Ошибка ${res.status}`);
    return data;
  }
  function toast(message) {
    const node = $('#toast'); node.textContent = message; node.classList.add('show');
    clearTimeout(toast.timer); toast.timer = setTimeout(() => node.classList.remove('show'), 3000);
  }
  function track(name, metadata = {}) {
    api('/api/events', { method:'POST', body:JSON.stringify({ event:name, guest_id:state.guestId, metadata }) }).catch(() => {});
  }
  function loadCart() {
    try { state.cart = JSON.parse(localStorage.getItem(cartKey) || '{}') || {}; } catch { state.cart = {}; }
  }
  function saveCart() { localStorage.setItem(cartKey, JSON.stringify(state.cart)); }
  function productById(id) { return state.products.find(p => p.id === id); }
  function cartItems() {
    return Object.entries(state.cart).map(([id, quantity]) => ({ id, quantity })).filter(x => productById(x.id) && x.quantity > 0);
  }
  function cartCount() { return cartItems().reduce((n, x) => n + x.quantity, 0); }
  function openModal(html) { $('#modalContent').innerHTML = html; $('#modal').hidden = false; }
  function closeModal() { $('#modal').hidden = true; $('#modalContent').innerHTML = ''; }

  function applySiteSettings(settings = {}) {
    if (settings.hero_title) $('#heroTitle').textContent = settings.hero_title;
    if (settings.hero_text) $('#heroText').textContent = settings.hero_text;
    if (settings.hero_cta) $('#heroCta').textContent = settings.hero_cta;
    if (settings.promo_title) $('#promoTitle').textContent = settings.promo_title;
    if (settings.promo_text) $('#promoText').textContent = settings.promo_text;
    if (settings.footer_notice) $('#footerNotice').textContent = settings.footer_notice;
  }
  function renderCategories() {
    const cats = ['all', ...new Set(state.products.map(p => p.category))];
    $('#categories').innerHTML = cats.map(c => `<button class="chip ${state.category === c ? 'active' : ''}" data-category="${esc(c)}">${c === 'all' ? 'Всё' : esc(c)}</button>`).join('');
    $$('#categories [data-category]').forEach(btn => btn.addEventListener('click', () => { state.category = btn.dataset.category; renderCategories(); renderProducts(); }));
  }
  function renderProducts() {
    let list = [...state.products].filter(p => (state.category === 'all' || p.category === state.category) && `${p.title} ${p.description}`.toLowerCase().includes(state.search.toLowerCase()));
    if (state.sort === 'price-asc') list.sort((a,b) => Number(!!a.price_on_request)-Number(!!b.price_on_request) || a.price-b.price);
    if (state.sort === 'price-desc') list.sort((a,b) => Number(!!a.price_on_request)-Number(!!b.price_on_request) || b.price-a.price);
    if (state.sort === 'title') list.sort((a,b) => a.title.localeCompare(b.title, 'ru'));
    $('#products').innerHTML = list.length ? list.map(p => {
      const fallback = `/static/images/${encodeURIComponent(p.image || 'opt_hero.svg')}`;
      const photo = p.image_url ? esc(p.image_url) : fallback;
      const priceNote = p.price_on_request ? 'Стоимость согласуется с менеджером' : (p.price_verified ? `${esc(p.unit)} · цена подтверждена` : `${esc(p.unit)} · предварительная цена`);
      const priceLabel = p.price_on_request ? 'По запросу' : money(p.price);
      const stockNote = p.stock_confirmed ? `Остаток: ${Number(p.stock)}` : 'Наличие уточняется';
      const action = p.price_on_request ? `<a class="add-button" href="https://vk.ru/rakovar_yar" target="_blank" rel="noopener">Уточнить ↗</a>` : `<button class="add-button" data-add="${esc(p.id)}">В корзину +</button>`;
      return `<article class="product-card">
      <div class="product-image"><img loading="lazy" src="${photo}" onerror="this.onerror=null;this.src='${fallback}'" alt="${esc(p.title)}"><span class="product-badge">${esc(p.badge || 'РАКОВАРЪ')}</span></div>
      <div class="product-body"><div class="product-meta"><span>${esc(p.category)}</span><span>${stockNote}</span></div><h3>${esc(p.title)}</h3><p>${esc(p.description)}${p.weight_label ? ` Вес: ${esc(p.weight_label)}.` : ''}</p>
      <div class="product-foot"><div class="price"><strong>${priceLabel}</strong><small>${priceNote}</small></div>${action}</div>${p.source_url ? `<a class="product-source" href="${esc(p.source_url)}" target="_blank" rel="noopener">Источник позиции ↗</a>` : ''}</div></article>`;
    }).join('') : '<div class="empty-state">Ничего не найдено. Попробуйте изменить запрос.</div>';
    $$('[data-add]').forEach(btn => btn.addEventListener('click', () => addToCart(btn.dataset.add)));
  }
  function renderBuilder() {
    const preferred = ['crayfish-standart-trad','set-firmenny','shrimp-assorted-boiled','mussels-wine'];
    const picks = preferred.map(id => productById(id)).filter(p => p && !p.price_on_request);
    $('#builderItems').innerHTML = picks.map((p, i) => `<div class="builder-item"><label><input type="checkbox" data-build="${esc(p.id)}" ${i < 2 ? 'checked' : ''}> <span>${esc(p.title)}</span></label><b>${money(p.price)}</b></div>`).join('');
    $$('[data-build]').forEach(el => el.addEventListener('change', updateBuilderTotal)); updateBuilderTotal();
  }
  function updateBuilderTotal() {
    const sum = $$('[data-build]:checked').reduce((n, el) => n + (productById(el.dataset.build)?.price || 0), 0);
    $('#builderTotal').textContent = money(sum);
  }
  function addToCart(id, qty = 1) {
    const p = productById(id); if (!p) return;
    const next = (state.cart[id] || 0) + qty;
    if (next > p.stock) { toast('В демо-каталоге недостаточно тестового остатка.'); return; }
    state.cart[id] = next; saveCart(); updateCart(); track('add_to_cart', { product_id:id, quantity:qty }); toast('Добавлено в корзину');
  }
  function updateCart() {
    const items = cartItems();
    $('#cartCount').textContent = cartCount();
    $('#cartItems').innerHTML = items.length ? items.map(({id,quantity}) => { const p=productById(id); return `<div class="cart-line"><div><b>${esc(p.title)}</b><small>${money(p.price)} · ${esc(p.unit)}</small></div><div class="qty-control"><button data-dec="${esc(id)}" aria-label="Уменьшить">−</button><b>${quantity}</b><button data-inc="${esc(id)}" aria-label="Увеличить">+</button></div></div>`; }).join('') : '<div class="empty-state">Корзина пока пуста. Выберите что-нибудь вкусное.</div>';
    $$('[data-dec]').forEach(b => b.addEventListener('click', () => changeQty(b.dataset.dec, -1)));
    $$('[data-inc]').forEach(b => b.addEventListener('click', () => changeQty(b.dataset.inc, 1)));
    quoteCart();
  }
  function changeQty(id, delta) {
    const p = productById(id); if (!p) return;
    const next = (state.cart[id] || 0) + delta;
    if (next <= 0) delete state.cart[id];
    else if (next <= p.stock) state.cart[id] = next;
    else toast('Доступное количество ограничено тестовым остатком.');
    saveCart(); updateCart();
  }
  async function quoteCart() {
    const items = cartItems();
    if (!items.length) {
      $('#subtotal').textContent = money(0); $('#discount').textContent = money(0); $('#deliveryCost').textContent = money(state.delivery === 'pickup' ? 0 : 350); $('#total').textContent = money(0); return;
    }
    try {
      const q = await api('/api/checkout/quote', { method:'POST', body:JSON.stringify({ items, promo_code:state.promo, delivery_mode:state.delivery }) });
      $('#subtotal').textContent = money(q.subtotal_rub); $('#discount').textContent = '−' + money(q.discount_rub); $('#deliveryCost').textContent = money(q.delivery_rub); $('#total').textContent = money(q.total_rub);
      if (state.promo) $('#promoMessage').textContent = q.promo_valid ? `Промокод применён: ${q.promo_message}` : q.promo_message;
    } catch (e) { $('#promoMessage').textContent = e.message; }
  }
  function renderPrizes(prizes) {
    const icons = { coupon:'％', delivery:'↗', gift:'🎁', points:'✦' };
    $('#prizeList').innerHTML = prizes.length ? prizes.map(p => `<div class="prize-row"><span class="prize-emoji">${icons[p.kind] || '🎁'}</span><div><b>${esc(p.title)}</b><small>${esc(p.partner || 'Партнёр')} · ${esc(p.description)}</small></div></div>`).join('') : '<div class="empty-state">Призы пока не добавлены.</div>';
  }
  async function refreshGame() {
    const p = await api(`/api/game/profile?guest_id=${encodeURIComponent(state.guestId)}`);
    $('#ticketBalance').textContent = p.tickets;
    $('#headerTicketBalance')?.remove();
    const history = await api(`/api/game/history?guest_id=${encodeURIComponent(state.guestId)}`);
    $('#gameHistory').textContent = history.length ? 'Последние результаты: ' + history.slice(0,3).map(x => x.prize_title + (x.redemption_code ? ` [${x.redemption_code}]` : '')).join(' · ') : 'История ваших тестовых розыгрышей появится здесь.';
  }
  async function refreshReferral() {
    const data = await api(`/api/referrals/profile?guest_id=${encodeURIComponent(state.guestId)}`);
    state.referral = data;
    $('#referralCode').textContent = data.code;
    $('#referralStats').textContent = `Приглашено: ${data.total} · Выполнили условие: ${data.qualified} · Ожидают покупки: ${data.pending}`;
    $('#referrerReward').textContent = `${data.rules.referrer_tickets} билетов`;
    $('#friendReward').textContent = `${data.rules.friend_tickets} билетов`;
    $('#referralTier').textContent = `Уровень «${data.tier.name}» · покупки за 365 дней: ${money(data.tier.spend_365d)}. ${data.tier.next_tier ? `До уровня «${data.tier.next_tier}»: ${money(data.tier.to_next_tier)}.` : 'Достигнут высший уровень.'}`;
  }
  async function attachReferralFromUrl() {
    const queryCode = new URLSearchParams(location.search).get('ref');
    const startCode = state.maxStartParam.startsWith('ref_') ? state.maxStartParam.slice(4) : '';
    const code = queryCode || startCode;
    if (!code) return;
    try {
      const result = await api('/api/referrals/attach', { method:'POST', body:JSON.stringify({ guest_id:state.guestId, code }) });
      toast(result.message);
      history.replaceState({}, '', location.pathname + location.hash);
    } catch (error) {
      if (!['referral_already_attached','referral_not_new_customer'].includes(error.message)) toast(error.message);
      history.replaceState({}, '', location.pathname + location.hash);
    }
  }
  async function spin() {
    const btn = $('#spinButton'); btn.disabled = true; btn.textContent = 'Колесо вращается…';
    try {
      const result = await api('/api/game/spin', { method:'POST', body:JSON.stringify({ guest_id:state.guestId }) });
      const turns = 5 * 360 + Math.floor(Math.random() * 360);
      $('#wheel').style.transform = `rotate(${turns}deg)`;
      await new Promise(resolve => setTimeout(resolve, 4100));
      await refreshGame();
      openModal(`<div class="eyebrow">ВАШ РЕЗУЛЬТАТ</div><h3>Поздравляем!</h3><p style="font:700 25px var(--serif);color:var(--gold2)">${esc(result.prize.title)}</p><p>${esc(result.prize.description)}</p>${result.redemption_code?`<p>Тестовый код: <b style="color:var(--gold2)">${esc(result.redemption_code)}</b></p>`:''}<p class="fine-print">${esc(result.message)}</p><button class="btn btn-primary btn-wide" id="prizeModalOk">Отлично</button>`);
      $('#prizeModalOk').addEventListener('click', closeModal);
      track('wheel_spin', { prize_id:result.prize.id });
    } catch (e) { toast(e.message); }
    finally { btn.disabled = false; btn.innerHTML = 'Использовать билет <span>↗</span>'; }
  }
  function renderContests(contests) {
    state.contests = contests;
    $('#contestList').innerHTML = contests.length ? contests.map(c => `<article class="contest-card"><span class="tiny-label">АКТИВНОСТЬ · ДО ${esc(c.ends_at)}</span><h3>${esc(c.title)}</h3><p>${esc(c.description)}</p><div class="contest-prize">Приз: ${esc(c.prize_title)}</div><p class="fine-print">${esc(c.rules)}</p><div class="contest-actions"><button class="btn btn-outline" data-enter-contest="${esc(c.id)}">Участвовать в демо</button><button class="btn btn-ghost" data-share-contest="${esc(c.id)}">Поделиться</button></div></article>`).join('') : '<div class="empty-state">Активных конкурсов сейчас нет.</div>';
    $$('[data-enter-contest]').forEach(btn => btn.addEventListener('click', () => contestModal(btn.dataset.enterContest)));
    $$('[data-share-contest]').forEach(btn => btn.addEventListener('click', () => shareContest(btn.dataset.shareContest)));
  }
  async function shareContest(id) {
    const c=state.contests.find(x=>x.id===id); if(!c) return;
    const link=`${window.location.origin}/#club`;
    const text=`🦞 РАКОВАРЪ · ${c.title}\nПриз: ${c.prize_title}\nУчаствуйте в клубной активности!`;
    try {
      if(window.WebApp?.shareMaxContent) await window.WebApp.shareMaxContent({text,link});
      else if(navigator.share) await navigator.share({title:c.title,text,url:link});
      else { await navigator.clipboard.writeText(`${text}\n${link}`); toast('Ссылка на конкурс скопирована.'); }
    } catch(error) { if(error?.name!=='AbortError') toast('Не удалось открыть меню отправки.'); }
  }
  function contestModal(id) {
    const c = state.contests.find(x => x.id === id); if (!c) return;
    openModal(`<div class="eyebrow">ДЕМО-УЧАСТИЕ</div><h3>${esc(c.title)}</h3><p>${esc(c.description)}</p><form id="contestEntryForm"><label class="tiny-label">Ваше имя / псевдоним</label><input name="alias" minlength="2" maxlength="40" required placeholder="Например, Морской гурман"><label class="tiny-label">Почему вам нравится такая идея?</label><textarea name="answer" minlength="5" maxlength="500" required placeholder="Короткий ответ"></textarea><button class="btn btn-primary btn-wide" type="submit">Отправить тестовую заявку</button></form><p class="fine-print">Не указывайте телефон, адрес и другие личные данные. В демо-режиме это не настоящий конкурс.</p>`);
    $('#contestEntryForm').addEventListener('submit', async e => {
      e.preventDefault(); const f = new FormData(e.currentTarget);
      try { const r = await api(`/api/contests/${encodeURIComponent(id)}/entries`, { method:'POST', body:JSON.stringify({ guest_id:state.guestId, alias:f.get('alias'), answer:f.get('answer') }) }); closeModal(); await refreshGame(); toast(r.tickets_awarded ? `${r.message} Начислено билетов: ${r.tickets_awarded}.` : r.message); track('contest_entry',{contest_id:id}); }
      catch (err) { toast(err.message); }
    });
  }
  function bindEvents() {
    $('#search').addEventListener('input', e => { state.search=e.target.value; renderProducts(); });
    $('#sort').addEventListener('change', e => { state.sort=e.target.value; renderProducts(); });
    $('#cartOpen').addEventListener('click', () => { $('#cartBackdrop').hidden=false; updateCart(); track('checkout_started'); });
    $('#cartClose').addEventListener('click', () => $('#cartBackdrop').hidden=true);
    $('#cartBackdrop').addEventListener('click', e => { if (e.target.id === 'cartBackdrop') $('#cartBackdrop').hidden=true; });
    $('#modalClose').addEventListener('click', closeModal); $('#modal').addEventListener('click', e => { if (e.target.id === 'modal') closeModal(); });
    $$('input[name="delivery"]').forEach(el => el.addEventListener('change', () => { state.delivery=el.value; quoteCart(); }));
    $('#applyPromo').addEventListener('click', () => { state.promo=$('#promoCode').value.trim().toUpperCase(); quoteCart(); track('promo_applied',{code:state.promo}); });
    $('#checkoutForm').addEventListener('submit', async e => {
      e.preventDefault(); if (!cartItems().length) return toast('Сначала добавьте товары в корзину.');
      const btn = e.submitter; btn.disabled=true;
      try {
        const result = await api('/api/orders', { method:'POST', body:JSON.stringify({ guest_id:state.guestId, items:cartItems(), promo_code:state.promo, delivery_mode:state.delivery, name:$('#customerName').value, phone:$('#customerPhone').value, consent:$('#consent').checked }) });
        state.cart={}; saveCart(); updateCart(); $('#cartBackdrop').hidden=true; e.currentTarget.reset(); state.promo=''; $('#promoCode').value='';
        openModal(`<div class="eyebrow">ДЕМО-ЗАКАЗ СОЗДАН</div><h3>Спасибо за тестирование!</h3><p style="font:700 24px var(--serif);color:var(--gold2)">${esc(result.order_id)}</p><p>${esc(result.message)}</p><p>Итого по расчёту: <b>${money(result.total_rub)}</b></p><button class="btn btn-primary btn-wide" id="orderDone">Вернуться на витрину</button>`);
        $('#orderDone').addEventListener('click',closeModal); toast('Тестовый заказ появился в демо-админке.');
      } catch (err) { toast(err.message); }
      finally { btn.disabled=false; }
    });
    $('#spinButton').addEventListener('click',spin);
    $('#shareReferral').addEventListener('click',async()=>{
      if(!state.referral)return;
      const webLink=`${location.origin}/?ref=${encodeURIComponent(state.referral.code)}#referrals`;
      const botName=document.body.dataset.maxBotUsername || 'id7606139934_5_bot';
      const maxLink=`https://max.ru/${encodeURIComponent(botName)}?startapp=ref_${encodeURIComponent(state.referral.code)}`;
      const message=`🦞 Приглашаю в клуб РАКОВАРЪ! Используй мой код ${state.referral.code}. После первой покупки от ${money(state.referral.rules.minimum_order_rub)} получишь ${state.referral.rules.friend_tickets} клубных билетов, а мне начислятся ${state.referral.rules.referrer_tickets}. Открой мини-приложение MAX: ${maxLink} Или сайт: ${webLink}`;
      track('referral_shared',{code:state.referral.code});
      try{if(window.WebApp?.shareMaxContent)await window.WebApp.shareMaxContent({text:message,link:maxLink});else if(navigator.share)await navigator.share({title:'Клуб РАКОВАРЪ',text:message,url:maxLink});else{await navigator.clipboard.writeText(message);toast('Приглашение скопировано.');}}catch(e){if(e?.name!=='AbortError')toast('Не удалось поделиться приглашением.');}
    });
    $('#addBundle').addEventListener('click',()=>{const chosen=$$('[data-build]:checked').map(el=>el.dataset.build);if(!chosen.length)return toast('Выберите хотя бы одну позицию.');chosen.forEach(id=>{const p=productById(id);if(p&&((state.cart[id]||0)<p.stock))state.cart[id]=(state.cart[id]||0)+1;});saveCart();updateCart();toast('Состав набора добавлен в корзину.');$('#cartBackdrop').hidden=false;});
    $$('[data-copy]').forEach(btn=>btn.addEventListener('click',async()=>{try{await navigator.clipboard.writeText(btn.dataset.copy);toast(`Промокод ${btn.dataset.copy} скопирован`);}catch{ $('#promoCode').value=btn.dataset.copy; $('#cartBackdrop').hidden=false;toast('Промокод перенесён в корзину.');}}));
    $('#mobileMenu').addEventListener('click',()=>$('.main-nav').classList.toggle('open'));
    $$('.main-nav a').forEach(a=>a.addEventListener('click',()=>$('.main-nav').classList.remove('open')));
  }
  async function initIdentity() {
    const webApp = window.WebApp;
    if (webApp && typeof webApp.initData === 'string' && webApp.initData.length) {
      try {
        const response = await fetch('/api/max/auth', {
          method:'POST', credentials:'same-origin', headers:{'Content-Type':'application/json'},
          body:JSON.stringify({init_data:webApp.initData})
        });
        const auth = await response.json().catch(() => ({}));
        if (!response.ok) throw new Error(auth.message || auth.error || `MAX auth ${response.status}`);
        state.guestId = auth.guest_id;
        state.csrf = auth.csrf_token || '';
        state.maxUser = auth.user || null;
        state.maxStartParam = auth.start_param || '';
        return;
      } catch (error) {
        console.warn('MAX initData validation failed; anonymous preview mode is used.', error);
      }
    }
    state.guestId = getGuestId();
  }

  async function init() {
    loadCart();
    try {
      await initIdentity();
      const data=await api(`/api/bootstrap?guest_id=${encodeURIComponent(state.guestId)}`);
      state.csrf=data.csrf_token || state.csrf;
      await attachReferralFromUrl();
      state.products=data.products; applySiteSettings(data.settings); renderCategories(); renderProducts(); renderBuilder(); renderPrizes(data.prizes); renderContests(data.contests); await refreshGame(); await refreshReferral();
      if ($('#spinHint') && data.loyalty_rules) $('#spinHint').textContent = `Билеты за покупки: 1 билет за каждые ${money(data.loyalty_rules.rub_per_ticket)} подтверждённой оплаты. Дополнительные билеты — за акции и конкурсы по их правилам.`;
      if (state.maxUser) toast(`Вы вошли через MAX, ${state.maxUser.first_name || 'добро пожаловать'}!`);
    } catch (e) { $('#products').innerHTML=`<div class="empty-state">Не удалось загрузить витрину: ${esc(e.message)}</div>`; }
    bindEvents(); updateCart(); track('page_view');
  }
  document.addEventListener('DOMContentLoaded',init);
})();
